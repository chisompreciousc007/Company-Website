<footer>
            <div class="footer_top">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="payment">
                                <img src="images/bitcoin_logo.png" alt="bitcoin_logo" class="img-responsive" />
                                <span>Accepted Here</span>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="footer_menu">
                                <ul>
                                    <li><a href="indeex.php">Home</a></li>
                                    <li><a href="about.php">About Us</a></li>
                                    <li><a href="faq.php">Faq</a></li>
                                    <li><a href="rules.php">Terms and Agreement</a></li>
                                    <li><a href="support.php">Support</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-2">
                        <h4 style="color: white;">Language</h4>
            <div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                                             </div>
                    </div>
                </div>
            </div>
            <div class="footer_bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <h6>© 2020 MarketExchangeFX. All Rights Reserved.</h6>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
