<section class="secure">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="owl-carousel secure_carousel owl-theme" style="opacity: 1; display: block;">
                                <div class="owl-wrapper-outer">
                                    <div class="owl-wrapper" style="width: 4416px; left: 0px; display: block;">
                                        <div class="owl-item" style="width: 276px;">
                                            <div class="item">
                                                <div class="secure_inner">
                                                    <img src="images/secure_icon_1.png" alt="secure_icon"
                                                        class="img-responsive">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 276px;">
                                            <div class="item">
                                                <div class="secure_inner">
                                                    <img src="images/secure_icon_2.png" alt="secure_icon"
                                                        class="img-responsive">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 276px;">
                                            <div class="item">
                                                <div class="secure_inner">
                                                    <img src="images/secure_icon_3.png" alt="secure_icon"
                                                        class="img-responsive">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 276px;">
                                            <div class="item">
                                                <div class="secure_inner">
                                                    <img src="images/secure_icon_4.png" alt="secure_icon"
                                                        class="img-responsive">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 276px;">
                                            <div class="item">
                                                <div class="secure_inner">
                                                    <img src="images/secure_icon_5.png" alt="secure_icon"
                                                        class="img-responsive">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 276px;">
                                            <div class="item">
                                                <div class="secure_inner">
                                                    <img src="images/secure_icon_6.png" alt="secure_icon"
                                                        class="img-responsive">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 276px;">
                                            <div class="item">
                                                <div class="secure_inner">
                                                    <img src="images/secure_icon_1.png" alt="secure_icon"
                                                        class="img-responsive">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 276px;">
                                            <div class="item">
                                                <div class="secure_inner">
                                                    <img src="images/secure_icon_2.png" alt="secure_icon"
                                                        class="img-responsive">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>








                                <div class="owl-controls clickable">
                                    <div class="owl-pagination">
                                        <div class="owl-page active"><span class=""></span></div>
                                        <div class="owl-page"><span class=""></span></div>
                                        <div class="owl-page"><span class=""></span></div>
                                        <div class="owl-page"><span class=""></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
