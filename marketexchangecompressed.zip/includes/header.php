<header>
            <div class="header_top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-4">
                            <div class="logo">
                                <a href="indexbc14.html?a=home"><img src="images/logo.png" alt="logo" style="width: 145px;height: 80px;"
                                        class="img-responsive" /></a>
                                <!-- <ul>
                                    <a href="#" target="_blank"><img src="#"></a>
                                </ul> -->
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-4 col-4">
                            <div class="header_top_middle">
                                <h4><i class="fa fa-bitcoin"></i>Btc/Usd <span class="btc-usd"><span class="price">- - -
                                            -</span></span></h4>

                                <a href="https://t.me/phoenixbtcmining" target="_blank"><img src="images/tel.png"
                                        class="face"></a>
                                        <a href="https://wa.me/2348036485194" target="_blank"><img src="images/whatsapp.png"
                                        class="face"></a>


                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4 col-4">
                            <div class="header_top_right">
                                <ul>
                                <li><a class="btn btn-default" href="login.php">Login</a></li>
                                        <li><a class="btn btn-primary" href="signup.php">Signup</a></li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="headermenu">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <nav class="navbar navbar-inverse">
                                <div class="navbar-header">
                                    <h5>Main Menu</h5>
                                    <button type="button" class="navbar-toggle" data-toggle="collapse"
                                        data-target="#myNavbar">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                                <div class="collapse navbar-collapse" id="myNavbar">
                                    <ul class="nav navbar-nav">
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about.php">About Us</a></li>
                                        <li><a href="faq.php">FAQ</a></li>

                                        <li><a href="support.php">Support</a></li>


                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div
        style="
          height: 62px;
          background-color: #1d2330;
          overflow: hidden;
          text-align: right;
          line-height: 14px;
          block-size: 40px;
          font-size: 12px;
          font-feature-settings: normal;
          text-size-adjust: 100%;
          padding: 1px;
          padding: 0px;
          margin: 0px;
          width: 100%;
        "
      >
        <div style="height: 40px; padding: 0px; margin: 0px; width: 100%">
          <iframe
            src="https://widget.coinlib.io/widget?type=horizontal_v2&amp;theme=dark&amp;pref_coin_id=1505&amp;invert_hover=no"
            width="100%"
            height="36px"
            scrolling="auto"
            marginwidth="0"
            marginheight="0"
            frameborder="0"
            border="0"
            style="border: 0; margin: 0; padding: 0"
          ></iframe>
        </div>
      </div>
        </header>
