<?php
require_once 'includes/head.php';
// require_once 'includes/functions.php';
?>
<body>


<wrapper>
<?php
require_once 'includes/header2.php';
?>
    <section class="inner_page_heading">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="main_title">
                        <h3>About Us</h3>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <div class="bottom_body inner_page_body">
        <section class="index_about">
            <div class="container">
                <div class="index_about_inner">
                    <div class="row">
                        <div class="col-sm-12">
                            <h2 class="common_heading">Welcome to MarketExchangeFX</h2>
                        </div>
                        <div class="col-sm-7">
                            <div class="about_left">
                                <p>MarketExchangeFX  focus solely on bitcoin mining.MarketExchangeFX was born in 2016 to give users an amazing, safe and reliable cloud mining platform. The ease and features of our website have grown our customer base to significant level which became our inspiration to open up new mining farms lately. We are dealing with cryptocurrency from when the concept of Bitcoin was introduced.

                                MarketExchangeFX is managed by proficient personnel comprising of brilliant programmers and engineers. our motto is to believe cryptocurrency is the future of global economy.

With the experience of many years in mining of cryptos, we have realized the need of safe, effective and prompt cloud mining servers in the industry. Consequently, we came up with the idea and technology to make mining accessible to all regardless of their age, location, budget or technical knowledge.

Being a part of this evolving reality is what drives us to establish ourselves as the leader and it keeps us going in providing our customers with the best cryptocurrency mining service. Try the future digital currency now.</p>
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="about_right" style="margin-top:55px;">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="work_process">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <div class="work_process_box">
                            <div class="work_process_box_inner">
                                <img src="images/wrkprcsicn1.png" alt="wrkprcsicn1" class="img-responsive" />
                                <h5>Cloud based GHS</h5>
                                <p>An innovative method to earn Bitcoins through collective <br>mining...</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <div class="work_process_box">
                            <div class="work_process_box_inner">
                                <img src="images/wrkprcsicn2.png" alt="wrkprcsicn1" class="img-responsive" />
                                <h5>Get Easy GH/S</h5>
                                <p>Buy easily Hash Power, get your<br> GH/S and start to <br> earn...</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">
                       <div class="work_process_box">
                            <div class="work_process_box_inner">
                                <img src="images/wrkprcsicn3.png" alt="wrkprcsicn1" class="img-responsive" />
                                <h5>Real-Time Earnings</h5>
                                <p>You can check the status of your earnings from your panel, they<br> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <div class="work_process_box">
                            <div class="work_process_box_inner">
                                <img src="images/wrkprcsicn4.png" alt="wrkprcsicn1" class="img-responsive" />
                                <h5>Withdraw Bitcoins</h5>
                                <p>You can withdraw the profit received in accordance with the contracts instantly.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="services" style="margin-bottom:60px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                       <div class="services_left" style="margin-left: 130px;">

                            <ul <ul style="margin-top: 100px;">>

                            <li>
                                <h4>MarketExchangeFX<p>12 Queensway, London <br>United Kingdom</p></h4></li>
                                <li>
                                <h4>UK COMPANY REGISTRATION DETAILS:<p>Company Registration Number 12518089</p></h4></li>
                            </ul>







                                <a style="font-size:12px;margin-right:10px;" class="btn btn-default" href="images/certificate.jpg" target="_blank">View Certificate</a>





                         </div>
                    </div>
                    <div class="col-md-5 col-sm-12">
                        <div class="services_right">
                            <div class="office-image">



                            </div>

                        </div>
                       <div class="services_right">
                            <span><img src="images/certificate_img.jpg" alt="certificate_img" class="video_img_1 img-responsive" />

                            <a href="#"><i class="fa fa-play"></i></a></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>


  <section class="secure">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="owl-carousel secure_carousel">
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_1.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_2.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_3.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_4.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_5.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_6.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_1.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_2.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

       </div>


       <?php
require_once 'includes/footer.php';
?>
</wrapper>


</body>
</html>
