<?php
require_once 'includes/head.php';
// require_once 'includes/functions.php';
?>
<body>


<wrapper>
<?php
require_once 'includes/header2.php';
?>
    <section class="inner_page_heading">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="main_title">
                        <h3>faq</h3>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <div class="bottom_body inner_page_body">

    	<section class="common_page">
            <div class="container">


<script>

$(document).ready(function() {
	$('.accordion').find('.accordion-toggle').click(function() {
		$(this).next().slideToggle('600');
		$(".accordion-content").not($(this).next()).slideUp('600');
	});
	$('.accordion-toggle').on('click', function() {
		$(this).toggleClass('active').siblings().removeClass('active');
	});
});


    </script>





<div class="faq_page">



  <div class="accordion">
<h4 style="border-bottom: 1px solid white;border-radius: 0px;width: 500px;color: #fff;height: 25px;margin-top:20px;text-transform: capitalize;">About Company</h4>
  <h4 class="accordion-toggle">What is MarketExchangeFX?</h4>
            <div class="accordion-content"><p>MarketExchangeFX is a Legal company that develops software and engages in cloud mining of bitcoin.</p></div>
  <h4 class="accordion-toggle">
Is MarketExchangeFX a registered and legal company?</h4>
            <div class="accordion-content"><p>Yes, MarketExchangeFX is registered in the United Kingdom as "MarketExchangeFX" with a registration number of  12518089.</p></div>

  <h4 class="accordion-toggle">Who can be our customer?</h4>
            <div class="accordion-content"><p>Any interested person can become an investor in MarketExchangeFX ,You only need to sign up and invest. Our support is always ready to help you.</div>
<h4 class="accordion-toggle">is the MarketExchangeFX platform safe?</h4>
            <div class="accordion-content"><p>Yes,we are using the most powerful DDoS protection in the industry with 100% up-time guarantee. Our worldwide web servers are protected by Cloudfare, the world's largest and most trusted DDoS protection and mitigation provider.</p></div>
												<h4 class="accordion-toggle">Is MarketExchangeFX platform realible?</h4>
            <div class="accordion-content"><p>MarketExchangeFX uses HTTPS encryption and the business is certified.</p></div>
  <h4 style="border-bottom: 1px solid white;border-radius: 0px;width: 500px;color: #fff;height: 25px;margin-top:20px;text-transform: capitalize;">Technical</h4>
  <h4 class="accordion-toggle">What is the maximum limit of hash power can I buy?</h4>
            <div class="accordion-content"><p>Each user can buy maximum 75010.0 TH/S equivalent to 100 BTC of contract purchased.</p></div>

<h4 class="accordion-toggle">How can I make a deposit?</h4>
            <div class="accordion-content"><p>In the "Deposit" section of your account, Choose a plan and transfer your investment amount to our bitcoin wallet, Your wallet will be credited immediately and your contract starts automatically.</p></div>

  <h4 class="accordion-toggle">What payment system can I use for buy hashpower and start to earn?</h4>
            <div class="accordion-content"><p>Given the fact that our company is involved in cryptocurrency mining, BitCoin and Bitcash is our only payment method.</p></div>
<h4 class="accordion-toggle">Can I make money without investing anything?</h4>
            <div class="accordion-content"><p>Yes, we have a referral program. You will receive a 5% bonus on deposits from members you invited to the platform.To do this, they must enroll with your referral link.
<br>Your referral link will be available in the dashboard after registration.</p></div>

  <h4 class="accordion-toggle">What is the minimum amount to withdraw?</h4>
            <div class="accordion-content"><p>Minimum withdrawal amount 120 USD</p></div>


													  <h4 class="accordion-toggle">Where can I buy BitCoin?</h4>
            <div class="accordion-content"><p>You can find cryptocurrency sellers here: https://howtobuybitcoins.info</p></div>







<h4 style="border-bottom: 1px solid white;border-radius: 0px;width: 500px;color: #fff;height: 25px;margin-top:20px;text-transform: capitalize;">General</h4>

		<h4 class="accordion-toggle">Can I own multiple accounts?</h4>
            <div class="accordion-content"><p>Each account is related to only one owner and multiple accounts are not allowed.
In case of violation, the account will be blocked. Unlocking the account will attract penalty fee.</p></div>
 <h4 class="accordion-toggle">What is a BitCoin address?</h4>
            <div class="accordion-content"><p>Bitcoin address is your ID (account, wallet number), starting with 1 or 3 and containing 27-34 alphanumeric Latin characters (other than 0, O, I). The address can also be represented as a QR-code, it is anonymous and does not contain information about the owner. For example, 1TopMSEYstRatqTFn5Au4m4GFg7xJaNVN2 or 398Tt1WpEZ73CNmQviecrnyiWrnqRhWNLy.</p></div>
<h4 class="accordion-toggle">What is the BitCoin confirmation?</h4>
            <div class="accordion-content"><p>All BitCoin operations are confirmed by a BitCoin network. Every single computer in the BitCoin network confirms your transaction, increasing the total number of confirmations. When the number of confirmations reaches a specific threshold, usually from 3 to 6, the funds appear in the recipient account. Usually, such a process takes from up to 90 minutes.</p></div>



  <h4 class="accordion-toggle">I can't find the answer to my question</h4>
            <div class="accordion-content"><p>Write us with the help of the form of  <a href="support.php">"Support"</a></p></div>

</div>

    </div>



       </div>
        </section>



  <section class="secure">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="owl-carousel secure_carousel">
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_1.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_2.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_3.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_4.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_5.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_6.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_1.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="secure_inner">
                                <img src="images/secure_icon_2.png" alt="secure_icon" class="img-responsive" />
                            </div>
                        </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

       </div>


       <?php
require_once 'includes/footer.php';
?>
</wrapper>


</body>








<!-- Mirrored from Phoenixmining.ltd/?a=faq by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 09 May 2020 13:39:23 GMT -->
</html>
