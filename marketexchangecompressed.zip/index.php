<?php
require_once 'includes/head.php';
?>

<body>
    <wrapper>

    <?php
require_once 'includes/header.php';
?>

        <section id="header-image2" class="index_banner">


            <div class="index_banner_inner">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="index_banner_content">
                                <h2>Invest in the Future <span>
                                        <p style="color:goldenrod"> <span>BITCOIN MINING</span></p>
                                    </span></h2>
                                <p> It’s easy - Our mining company is already set up and running.<br>
                                    Invest and start to earn  through our  mining
                                    service!
                                <p>
                                    <span>

                                        <br>



                                        <a class="btn btn-primary" href="signup.php">Start Now !</a>
                                        <a class="btn btn-primary" href="about.php">More
                                            info</a>
                                        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>




                                    </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div class="bottom_body">

            <section class="packages" data-wow-delay="2s">
                <div class="container">
                    <div class="packages_inner clearfix">
                        <div class="col-sm-4">
                            <div class="row">
                                <div class="package_box">
                                    <h2>3.20% <span style="display: inherit;text-align: center;">daily<br>/ Per
                                            Contract</span></h2>
                                    <ul>
                                        <li>1x Mining Power</li>
                                        <li>SHA-256 ASIC Mining</li>
                                        <li>7 days Contract</li>
                                        <li>Max 2596.5 TH/S Mining Outputs</li>

                                        <li>100 USD - 4,999 USD</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="row">
                                <div class="package_box">
                                    <h2>4.50% <span style="display: inherit;text-align: center;">daily<br>/ Per
                                            Contract</span></h2>
                                    <ul>
                                        <li>1.22x Mining Power</li>
                                        <li>SHA-256 ASIC Mining</li>
                                        <li>7 days Contract</li>
                                        <li>Max 6347.0 TH/S Mining Outputs</li>

                                        <li>5,000 USD - 49,999 USD</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="row">
                                <div class="package_box">
                                    <h2>149.80% <span style="display: inherit;text-align: center;">after<br>/ Per
                                            Contract</span></h2>
                                    <ul>
                                        <li>1.44x Mining Power</li>
                                        <li>SHA-256 ASIC Mining</li>
                                        <li>30 Days Contract</li>
                                        <li>Max 75010.0 TH/S Mining Outputs</li>

                                        <li>5,000 USD - 100,000 USD</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="calculator" style="display:none">
                <div class="container">
                    <div class="calculator_inner_grad">
                        <div class="calculator_inner">
                            <span><input type="submit" value="submit" /></span>
                            <div class="row">
                                <div class="col-sm-7 col-xs-12">

                                    <div class="calc_input">
                                        <i style="color:white;font-size: 30px;position: relative;top: 6px;right: 4px;"
                                            class="fa fa-btc" aria-hidden="true"></i>
                                        <span class="calc_input_1"><input style="font-size: 16px;width:90%"
                                                class="input-calc" value="0.001" min="0.001" value="100" name="money"
                                                id="money" type="text" autocomplete="off"
                                                placeholder="Enter Amount" /></span>

                                        <span class="calc_hashrate">

                                            <div class="calc_output" style="padding:0;">
                                                <h4>Hashpower: <span id="ghashDaily"> 0.000012</span>

                                            </div>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-sm-5 col-xs-12">
                                    <div class="calc_output">
                                        <h4>Profit in daily plans : <span style="text-align:right;"
                                                id="profitDaily">0.000012 BTC</span>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </div>
        </div>
        </div>
        </div>
        </div>
        </section>

        <section class="index_about">
            <div class="container">
                <div class="index_about_inner">
                    <div class="row">
                        <div class="col-sm-12">
                            <h2 class="common_heading">How it works</h2>
                        </div>
                        <div class="col-sm-6">
                            <div class="about_left">
                                <p>MarketExchangeFX offers you a smart way to invest your money. Our
                                    bitcoin mining platform is suitable
                                    for those who are novice to the world of crypto currencies,as well as for
                                    cryptocurrency experts and large-scale
                                    investors.
                                    MarketExchangeFX is one of the best in large scale multi-algorithm cloud mining
                                    service offering an alternative to those
                                    who would like to engage in Bitcoin and altcoin mining.

                                    We are a team of experts in the digital currency sector, and our bitcoin mining
                                    algorithm is designed to provide the
                                    most efficient and reliable bitcoin mining rentals. There is almost no risk attached to investing with our platform because we do not engage in trading but strictly on mining, and we are insured.</p>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="about_right" style="background: transparent;box-shadow: none;">
                                <ul>
                                    <li><img src="images/about_icon_1.png" alt="about_icon" class="img-responsive" />
                                        <h4>Power Allocation
                                            <p>You can invest in mining contracts that suits you.</p>
                                        </h4>
                                    </li>

                                    <h4>
                                        <p></p>
                                    </h4>
                                    </li>
                                    <li><img src="images/about_icon_3.png" alt="about_icon" class="img-responsive" />
                                        <h4>Instant Withdrawal
                                            <p>Sign into your dashboard , Choose the amount to withdraw and receive it
                                                instantly.The minimum withdrawal amount is 120 USD.</p>
                                        </h4>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="services">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="services_left">
                            <ul>
                                <li><img src="images/services_icon_1.png" alt="services_icon" class="img-responsive" />
                                    <h4>Simplicity<p>Our platform has been developed to ensure safe and effective use by
                                            any customer, with little technical know-how.</p>
                                    </h4>
                                </li>
                                <li><img src="images/services_icon_2.png" alt="services_icon" class="img-responsive" />
                                    <h4>24/7 Support<p>Availability of quality support to our customers is one of
                                            our main prioroties, our team of
                                            qualified staff is always ready to assist you.</p>
                                    </h4>
                                </li>
                                <li><img src="images/services_icon_3.png" alt="services_icon" class="img-responsive" />
                                    <h4>Live Dashboard<p>You can buy additional contract in real-time , keep track of
                                            each contract.

                                        </p>
                                    </h4>
                                </li>
                                <li><img src="images/services_icon_4.png" alt="services_icon" class="img-responsive" />
                                    <h4>Referral Bonus<p>MarketExchangeFX Referral Program gives
                                            5% for referrals, You can make money even without investing.</p>
                                    </h4>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="services_right">
                            <span><img src="images/video_img.png" alt="video_img" class="video_img_1 img-responsive" />
                                <img src="images/video_img.png" alt="video_img" class="video_img_2 img-responsive" />
                                <!-- <a href="#"><i class="fa fa-play"></i></a></span> -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="secure">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="owl-carousel secure_carousel">
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_1.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_2.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_3.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_4.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_5.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_6.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_1.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_2.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_3.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_4.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_5.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                            <div class="item">
                                <div class="secure_inner">
                                    <img src="images/secure_icon_6.png" alt="secure_icon" class="img-responsive" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        </div>


        <?php
require_once 'includes/footer.php';
?>


    </wrapper>
    <?php
require_once 'includes/snackbar.php';
?>
</body>
</html>
